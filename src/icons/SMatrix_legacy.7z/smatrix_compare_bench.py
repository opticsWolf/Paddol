# -*- coding: utf-8 -*-
"""
Created on Mon Dec 15 22:47:42 2025

@author: Frank
"""

import numpy as np
import time
import copy

# --- Imports ---
try:
    import ScatteringMatrix_legacy as legacy
    print("Successfully imported ScatteringMatrix_legacy.")
except ImportError:
    print("Error: 'ScatteringMatrix_legacy.py' not found. Please ensure it is in the same directory.")
    exit()

# Import your new wrapper function
# Assuming the wrapper is in 'smatrix_wrapper.py' or you paste it here.
# For this example, I will define the wrapper locally to ensure it runs self-contained.
from scattering_matrix import FastScatterMatrix

def ComputeRT_New(structure, lam, Fi):
    """ The FIXED wrapper for the new FastScatterMatrix """
    thicknesses = np.array([s[0] for s in structure])
    incoherent_flags = np.array([s[2] for s in structure], dtype=bool)
    
    if np.ndim(lam) == 0:
        num_wavs = 1; lam_arr = np.array([lam])
    else:
        num_wavs = len(lam); lam_arr = lam

    num_layers = len(structure)
    indices_matrix = np.empty((num_layers, num_wavs), dtype=np.complex128)

    for i in range(num_layers):
        N_i = structure[i][1]
        if np.ndim(N_i) == 0: indices_matrix[i, :] = N_i
        elif N_i.shape[0] == num_wavs: indices_matrix[i, :] = N_i
        else: raise ValueError(f"Index mismatch layer {i}")

    rough_types = np.zeros(num_layers, dtype=np.int32)
    rough_vals = np.zeros(num_layers, dtype=np.float64)
    
    # Handle Roughness (Legacy format: index 3)
    for i in range(num_layers):
        if len(structure[i]) > 3:
            r_val = structure[i][3]
            if r_val > 0:
                rough_types[i] = 1 # Linear (Legacy default)
                rough_vals[i] = r_val

    # CRITICAL FIX: Ensure Degrees are passed to class
    if np.abs(Fi) <= 2.0 * np.pi: theta_deg = np.degrees(Fi)
    else: theta_deg = Fi

    fsm = FastScatterMatrix(indices_matrix, thicknesses, incoherent_flags, 
                            rough_types, rough_vals, lam_arr, theta_deg)
    res = fsm.compute_RT()
    return res['Ru'], res['Rs'], res['Rp'], res['Tu'], res['Ts'], res['Tp']

# --- Simulation Setup ---

def run_comparison():
    # 1. Define Physics
    n_wavs = 500
    wavls = np.linspace(400, 800, n_wavs) # nm
    lambda_0 = 550.0
    
    # Material Indices (Complex)
    n_air   = np.full(n_wavs, 1.0 + 0.0j)
    n_bk7   = np.full(n_wavs, 1.52 + 0.0j)
    n_sio2  = np.full(n_wavs, 1.46 + 0.0j)
    n_ta2o5 = np.full(n_wavs, 2.10 + 0.0j)
    
    # Quarter Wave Thicknesses
    d_sio2 = lambda_0 / (4 * 1.46)
    d_ta2o5 = lambda_0 / (4 * 2.10)
    
    # 2. Build Structure: Air / (HL)^10 / BK7
    # Legacy Format: [thickness, N, incoherent, roughness]
    structure_template = []
    structure_template.append([0.0, n_air, False, 0.0]) # Ambient
    
    num_pairs = 10
    for i in range(num_pairs):
        structure_template.append([d_ta2o5, n_ta2o5, False, 0.0]) # H
        structure_template.append([d_sio2, n_sio2, False, 0.0])   # L
        
    structure_template.append([0.0, n_bk7, False, 0.0]) # Substrate
    
    fi_rad = np.deg2rad(45.0) # 45 degrees incidence

    print(f"--- COMPARISON START ---")
    print(f"Structure: {len(structure_template)} layers, {n_wavs} wavelengths")
    print(f"Angle: 45 degrees")

    # --- 3. Run Legacy Code ---
    print("\nRunning Legacy Code (Pure Python)...")
    
    # Deepcopy is CRITICAL because Legacy code modifies the list in-place
    struct_legacy = copy.deepcopy(structure_template)
    
    t0 = time.time()
    # Legacy returns average R, T
    R_old, T_old = legacy.ComputeRT(struct_legacy, wavls, fi_rad)
    dt_old = time.time() - t0
    
    print(f"Legacy Time: {dt_old:.4f} s")

    # --- 4. Run New Code ---
    print("\nRunning New Code (Numba Compiled)...")
    
    # JIT Warmup (First run includes compilation overhead)
    print("(Compiling JIT...)")
    struct_new = copy.deepcopy(structure_template)
    _ = ComputeRT_New(struct_new, wavls, fi_rad)
    
    # Timed Run
    t1 = time.time()
    num_runs = 1000 # Run 100 times to get measurable time if it's very fast
    for _ in range(num_runs):
        struct_new = copy.deepcopy(structure_template)
        R_new, Rs, Rp, T_new, Ts, Tp = ComputeRT_New(struct_new, wavls, fi_rad)
    dt_new_total = time.time() - t1
    dt_new_avg = dt_new_total / num_runs
    
    print(f"New Time (Avg of {num_runs}): {dt_new_avg:.6f} s")
    
    # --- 5. Analysis ---
    
    speedup = dt_old / dt_new_avg
    print(f"\n>>> Speedup Factor: {speedup:.1f}x <<<")
    
    # Check Accuracy (Compare R_old vs R_new_average)
    # legacy R is (Rs+Rp)/2, which matches New code 'Ru' (R_new variable above)
    diff = np.abs(R_old - R_new)
    max_diff = np.max(diff)
    
    print(f"\nAccuracy Check:")
    print(f"Max Difference in Reflectance: {max_diff:.2e}")
    if max_diff < 1e-10:
        print("✅ Results Match Perfectly!")
    else:
        print("⚠️ Significant Difference Detected (Check Angle Units?)")

    # --- 6. Table Output ---
    print("\nSample Data (550nm region):")
    print(f"{'Wav(nm)':<10} | {'R_Legacy':<10} | {'R_New':<10} | {'Diff':<10}")
    print("-" * 46)
    
    idx_center = np.argmin(np.abs(wavls - 550))
    indices = range(idx_center - 2, idx_center + 3)
    
    for i in indices:
        print(f"{wavls[i]:<10.1f} | {R_old[i]:<10.5f} | {R_new[i]:<10.5f} | {diff[i]:<10.1e}")

if __name__ == "__main__":
    run_comparison()