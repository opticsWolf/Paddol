import numpy as np
import sys

# Assuming FastScatterMatrix is available from your new module
# from .fast_scatter_matrix import FastScatterMatrix
from scattering_matrix import FastScatterMatrix

def ComputeRT(structure, lam, Fi):
    """
    Calculate reflection and transmission coefficients using the FastScatterMatrix class.
    Args:
        structure: List[List[Union[float, np.ndarray, bool]]]
        lam: Union[float, np.ndarray] - Wavelengths in nm
        Fi: Union[float, np.ndarray] - Angle of incidence (radians preferred)
    Returns:
        Tuple[R, Rs, Rp, T, Ts, Tp]
    """
    # 1. Adapt/Process Data
    # The structure format is assumed to be: [thickness_i, N_i(lambda), is_incoherent_i, roughness]
    thicknesses = np.array([s[0] for s in structure])
    incoherent_flags = np.array([s[2] for s in structure], dtype=bool)

    # Reformat indices: Extract N(lambda) for all layers into a (N_layers, N_wavs) matrix
    num_layers = len(structure)
    # Handle scalar lambda vs array lambda
    if np.ndim(lam) == 0:
        num_wavs = 1
        lam_arr = np.array([lam])
    else:
        num_wavs = len(lam)
        lam_arr = lam

    # Initialize index matrix (complex)
    indices_matrix = np.empty((num_layers, num_wavs), dtype=np.complex128)

    for i in range(num_layers):
        N_i = structure[i][1]
        if np.ndim(N_i) == 0:
            # If N_i is a single number (for all wavelengths)
            indices_matrix[i, :] = N_i
        elif N_i.shape[0] == num_wavs:
            # If N_i is an array of complex indices
            indices_matrix[i, :] = N_i
        else:
            raise ValueError(f"Index data shape mismatch for layer {i}.")

    # 2. Instantiate and Call the new FastScatterMatrix
    rough_types = np.zeros(num_layers, dtype=np.int32)
    rough_vals = np.zeros(num_layers, dtype=np.float64)

    # Ensure angle is in radians
    if np.abs(Fi) > 2.0 * np.pi:
        theta_rad = np.deg2rad(Fi) 
    else:
        theta_rad = Fi

    fsm = FastScatterMatrix(
        indices_matrix,
        thicknesses,
        incoherent_flags,
        rough_types,
        rough_vals, 
        lam_arr,
        theta_rad
    )

    # 3. Call the core engine
    res = fsm.compute_RT()

    # 4. Return in the original format
    return res['Ru'], res['Rs'], res['Rp'], res['Tu'], res['Ts'], res['Tp']


import numpy as np
import time

# Assuming FastScatterMatrix is available from your new module
from scattering_matrix import FastScatterMatrix

def ComputeRT(structure, lam, Fi):
    """
    Calculate reflection and transmission coefficients.
    """
    # 1. Adapt/Process Data
    thicknesses = np.array([s[0] for s in structure])
    incoherent_flags = np.array([s[2] for s in structure], dtype=bool)

    # Handle scalar lambda vs array lambda
    if np.ndim(lam) == 0:
        lam_arr = np.array([lam])
        num_wavs = 1
    else:
        lam_arr = lam
        num_wavs = len(lam)

    num_layers = len(structure)
    
    # Initialize index matrix
    indices_matrix = np.empty((num_layers, num_wavs), dtype=np.complex128)
    for i in range(num_layers):
        N_i = structure[i][1]
        if np.ndim(N_i) == 0:
            indices_matrix[i, :] = N_i
        elif N_i.shape[0] == num_wavs:
            indices_matrix[i, :] = N_i
        else:
            raise ValueError(f"Index data shape mismatch for layer {i}.")

    # 2. Instantiate FastScatterMatrix
    rough_types = np.zeros(num_layers, dtype=np.int32)
    rough_vals = np.zeros(num_layers, dtype=np.float64)

    fsm = FastScatterMatrix(
        indices_matrix,
        thicknesses,
        incoherent_flags,
        rough_types,
        rough_vals, 
        lam_arr,
        theta_def
    )

    # 3. Compute
    res = fsm.compute_RT()
    return res['Ru'], res['Rs'], res['Rp'], res['Tu'], res['Ts'], res['Tp']


if __name__ == "__main__":
    # --- 1. Data Setup ---
    n_wavs = 201
    wavls = np.linspace(400, 600, n_wavs)
    lambda_0 = 550.0 
    
    # Materials (BK7 Substrate, Air Ambient, SiO2/Ta2O5 Stack)
    n_air = np.full(n_wavs, 1.0 + 0.0j, dtype=np.complex128)
    n_bk7 = np.full(n_wavs, 1.515 + 0.0j, dtype=np.complex128)
    n_sio2 = np.full(n_wavs, 1.46 + 0.0j, dtype=np.complex128)
    n_ta2o5 = np.full(n_wavs, 2.10 + 0.0j, dtype=np.complex128)
    
    # QW Thicknesses
    d_sio2 = lambda_0 / (0.1 * 1.46)
    d_ta2o5 = lambda_0 / (0.1 * 2.10)
    
    # Build Structure: Air / (HL)^10 / BK7
    structure_template = []
    structure_template.append([0.0, n_air, False, 0.0])
    for i in range(10):
        structure_template.append([d_ta2o5*(1+i/2), n_ta2o5, False, 0.0])
        structure_template.append([d_sio2*(i+1), n_sio2, False, 0.0]) 
    structure_template.append([0.0, n_bk7, False, 0.0])
    
    # Angles to simulate
    angles_deg = np.linspace(0, 85, 5) 
    target_idx = np.argmin(np.abs(wavls - 550.0)) # Index for 550nm for printing

    # --- 2. Visualization Run (Single Pass) ---
    print(f"--- Visual Check: Angular Dependence (0-85 deg) ---")
    print(f"{'Angle (deg)':<12} | {'Rs @550nm':<12} | {'Rp @550nm':<12} | {'R_avg':<12}")
    print("-" * 55)

    # Run once to verify output and warm up JIT
    for angle in angles_deg:
        fi_rad = np.deg2rad(angle)
        structure_copy = [list(l) for l in structure_template]
        R_avg, Rs, Rp, T_avg, Ts, Tp = ComputeRT(structure_copy, wavls, fi_rad)
        print(f"{angle:<12.1f} | {Rs[target_idx]:<12.4f} | {Rp[target_idx]:<12.4f} | {R_avg[target_idx]:<12.4f}")

    print("-" * 55)
    print("\n--- Starting High-Volume Benchmark ---")

    # --- 3. Benchmark Loop ---
    
    benchmark_loops = 10  # <--- SET LOOP COUNT HERE
    total_calculations = benchmark_loops * len(angles_deg)
    
    print(f"Running angular sweep ({len(angles_deg)} angles) x {benchmark_loops} loops...")
    print(f"Total simulations: {total_calculations}")

    t_start = time.time()

    for i in range(benchmark_loops):
        # Inner loop: Iterate over all angles
        for angle in angles_deg:
            fi_rad = np.deg2rad(angle)
            
            # Deep copy structure to ensure clean state per run
            structure_copy = [list(l) for l in structure_template]
            
            # Compute (Printing suppressed for speed accuracy)
            ComputeRT(structure_copy, wavls, fi_rad)

    t_end = time.time()
    dt = t_end - t_start

    # --- 4. Performance Report ---
    total_wav_points = total_calculations * n_wavs
    print(f"\nExecution Time: {dt:.4f} seconds")
    print(f"Throughput:     {total_calculations / dt:.2f} angular sweeps/sec")
    print(f"Data Rate:      {total_wav_points / dt:.2e} wavelength-points/sec")